from zigzag.core import *

PEAK = 1
VALLEY = -1
